
class Node {
  int item, yukseklik;
  Node sol, sag;

  Node(int x) {
    item = x;
    yukseklik = 1;
  }
}


class AVLTree {
  Node root;

  int yukseklik(Node N) {
    if (N == null)
      return 0;
    return N.yukseklik;
  }

  int max(int x, int y) {
    return (x > y) ? x : y;
  }

  Node sagRotate(Node y) {
    Node x = y.sol;
    Node T2 = x.sag;
    x.sag = y;
    y.sol = T2;
    y.yukseklik = max(yukseklik(y.sol), yukseklik(y.sag)) + 1;
    x.yukseklik = max(yukseklik(x.sol), yukseklik(x.sag)) + 1;
    return x;
  }

  Node solRotate(Node x) {
    Node y = x.sag;
    Node T2 = y.sol;
    y.sol = x;
    x.sag = T2;
    x.yukseklik = max(yukseklik(x.sol), yukseklik(x.sag)) + 1;
    y.yukseklik = max(yukseklik(y.sol), yukseklik(y.sag)) + 1;
    return y;
  }

  
  int getDengeFaktoru(Node N) {
    if (N == null)
      return 0;
    return yukseklik(N.sol) - yukseklik(N.sag);
  }

  // node ekleme
  Node insertNode(Node node, int item) {

    if (node == null)
      return (new Node(item));
    if (item < node.item)
      node.sol = insertNode(node.sol, item);
    else if (item > node.item)
      node.sag = insertNode(node.sag, item);
    else
      return node;

    node.yukseklik = 1 + max(yukseklik(node.sol), yukseklik(node.sag));
    int DengeFaktoru = getDengeFaktoru(node);
    if (DengeFaktoru > 1) {
      if (item < node.sol.item) {
        return sagRotate(node);
      } else if (item > node.sol.item) {
        node.sol = solRotate(node.sol);
        return sagRotate(node);
      }
    }
    if (DengeFaktoru < -1) {
      if (item > node.sag.item) {
        return solRotate(node);
      } else if (item < node.sag.item) {
        node.sag = sagRotate(node.sag);
        return solRotate(node);
      }
    }
    return node;
  }

  Node nodeWithMimumValue(Node node) {
    Node current = node;
    while (current.sol != null)
      current = current.sol;
    return current;
  }

  
  Node deleteNode(Node root, int item) {

    
    if (root == null)
      return root;
    if (item < root.item)
      root.sol = deleteNode(root.sol, item);
    else if (item > root.item)
      root.sag = deleteNode(root.sag, item);
    else {
      if ((root.sol == null) || (root.sag == null)) {
        Node temp = null;
        if (temp == root.sol)
          temp = root.sag;
        else
          temp = root.sol;
        if (temp == null) {
          temp = root;
          root = null;
        } else
          root = temp;
      } else {
        Node temp = nodeWithMimumValue(root.sag);
        root.item = temp.item;
        root.sag = deleteNode(root.sag, temp.item);
      }
    }
    if (root == null)
      return root;

    
    root.yukseklik = max(yukseklik(root.sol), yukseklik(root.sag)) + 1;
    int DengeFaktoru = getDengeFaktoru(root);
    if (DengeFaktoru > 1) {
      if (getDengeFaktoru(root.sol) >= 0) {
        return sagRotate(root);
      } else {
        root.sol = solRotate(root.sol);
        return sagRotate(root);
      }
    }
    if (DengeFaktoru < -1) {
      if (getDengeFaktoru(root.sag) <= 0) {
        return solRotate(root);
      } else {
        root.sag = sagRotate(root.sag);
        return solRotate(root);
      }
    }
    return root;
  }

  void preOrder(Node node) {
    if (node != null) {
      System.out.print(node.item + " ");
      preOrder(node.sol);
      preOrder(node.sag);
    }
  }

  
  private void printTree(Node currPtr, String indent, boolean last) {
    if (currPtr != null) {
      System.out.print(indent);
      if (last) {
        System.out.print("R----");
        indent += "   ";
      } else {
        System.out.print("L----");
        indent += "|  ";
      }
      System.out.println(currPtr.item);
      printTree(currPtr.sol, indent, false);
      printTree(currPtr.sag, indent, true);
    }
  }

  
  public static void main(String[] args) {
    AVLTree tree = new AVLTree();
    tree.root = tree.insertNode(tree.root, 33);
    tree.root = tree.insertNode(tree.root, 13);
    tree.root = tree.insertNode(tree.root, 53);
    tree.root = tree.insertNode(tree.root, 9);
    tree.root = tree.insertNode(tree.root, 21);
    tree.root = tree.insertNode(tree.root, 61);
    tree.root = tree.insertNode(tree.root, 8);
    tree.root = tree.insertNode(tree.root, 11);
    tree.printTree(tree.root, "", true);
    tree.root = tree.deleteNode(tree.root, 13);
    System.out.println("Silindikten Sonra: ");
    tree.printTree(tree.root, "", true);
  }
}