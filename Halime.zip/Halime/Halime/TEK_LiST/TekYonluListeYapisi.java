public class TekYonluListeYapisi {
	Nesne govde=null;
	Nesne tail=null;
	void basaEkle(int x)
	{
		Nesne elements=new Nesne();
		elements.veri=x;
		
		if(govde==null)
		{
			elements.next=null;
			govde=elements;
			tail=elements;
			System.out.println("liste yapisi oluşturuldu,ilk elements eklendi");
			
		}
		else
		{
			
			elements.next=govde;
			govde=elements;
			System.out.println("başa elements eklendi");
			
		}
		
	}
	void sonaEkle(int x)
	{
		Nesne elements=new Nesne();
		elements.veri=x;
		
		if(govde==null)
		{
			elements.next=null;
			govde=elements;
			tail=elements;
			System.out.println("liste yapisi oluşturuldu ,ilk elements eklendi");
		}
		else
		{
			tail.next=elements;
			tail=elements;
			System.out.println("sona elements eklendi");
		}
	}
	void arayaEkle(int indis ,int x)
	{
		Nesne elements=new Nesne();
		elements.veri=x;
		
		if(govde==null && indis ==0)
		{
			elements.next=null;
			govde=elements;
			tail=elements;
			System.out.println("liste yapisi oluşturuldu,ilk elements eklendi");
		}
		else if(govde!= null && indis ==0)
		{
			elements.next=govde;
			govde=elements;
			System.out.println(indis + "indisinci siraya yeni elements eklendi");
			
		}
		else
		{
			int n=0;
			Nesne temp=govde;
			Nesne temp2=govde;
			while(temp.next!=null)
			{
				n++;
				temp2=temp;
				temp=temp.next;
			}
			
			if(n==indis)
			{
				temp2.next=elements;
				elements.next=temp;
				System.out.println("elements eklendi");
			}
			else
			{
				temp=govde;
				temp2=govde;
				int i= 0;
				while(i!=indis)
				{
					temp2=temp;
					temp=temp.next;
					i++;
					
					
				}
				temp2.next=elements;
				elements.next=temp;
				System.out.println(indis + ".siraya yeni elements eklendi");

			}
		}
	}
	void yazdir()
	{
		
		if(govde==null)
		{
			System.out.println("liste yapisi oluşturuldu,ilk elements eklendi");
		}
		else
		{
		Nesne temp=govde;
		System.out.print("baş->");
		while(temp!=null)
		{
			System.out.print(temp.veri+"->");
			temp=temp.next;
		}
		System.out.print("son.");
		}
	}
	
	}