public class uygulama {

	public static void main(String[] args) {
		
			TekYonluListeYapisi TYList=new TekYonluListeYapisi();
			TYList.basaEkle(13);
			TYList.sonaEkle(25);
			TYList.basaEkle(7);
			TYList.sonaEkle(45);
			TYList.sonaEkle(50);
			TYList.sonaEkle(42);
			
			TYList.arayaEkle(4,26);
			TYList.arayaEkle(5,40);

			

			TYList.yazdir();
			
	
	}

}
