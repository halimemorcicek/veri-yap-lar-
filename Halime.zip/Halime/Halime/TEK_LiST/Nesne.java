public class Nesne {
	
	int veri;
	Nesne next;

}

