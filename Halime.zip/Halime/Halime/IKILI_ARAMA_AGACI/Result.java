class Sonuc {
    private boolean Dengeli;
    private int yukseklik;

    private Sonuc(boolean Dengeli, int yukseklik) {
        this.Dengeli = Dengeli;
        this.yukseklik = yukseklik;
    }
    
    private Sonuc DengeliRecursive(Tree tree, int depth) {
    if (tree == null) {
        return new Sonuc(true, -1);
    }

    Sonuc solAltagacSonucu = DengeliRecursive(tree.left(), depth + 1);
    Sonuc sagAltagacSonucu = DengeliRecursive(tree.right(), depth + 1);

    boolean Dengeli = Math.abs(solAltagacSonucu.yukseklik - sagAltagacSonucu.yukseklik) <= 1;
    boolean subtreesAreBalanced = solAltagacSonucu.Dengeli && sagAltagacSonucu.Dengeli;
    int yukseklik = Math.max(solAltagacSonucu.yukseklik, sagAltagacSonucu.yukseklik) + 1;

    return new Sonuc(Dengeli && subtreesAreBalanced, yukseklik);
}
}

