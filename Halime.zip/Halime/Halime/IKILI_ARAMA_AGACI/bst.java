import javax.lang.model.util.ElementScanner6;


public class bst {
    Node root=null;
    
    class Node
    {
        private Node root;
        private Node sol;  
        private Node sag; 
        private int veri; 
        
        Node(int k)         
        {
            sol = sag = null;   
            veri = k;              
        }   
    }
    public void Ekle(int deger){
        Node temp=null;
        Node p=root;
        while (p!=null){
            temp=p;
            if(deger==p.veri) 
                return;
            else if(deger<p.veri)
                p=p.sol;
            else
                p=p.sag;
        }
        Node z=new Node(deger);
        z.veri=deger;
        z.sol=z.sag=null;
        if(root==null)
            root=z;
        else if(deger<temp.veri)
            temp.sol=z;
        else
            temp.sag=z;        
    }

   
    public void BulWhile(Node root, int deger) {
        Node p=root;
        while (p!=null){
            if(deger==p.veri){
                System.out.println("Bulunan değer: "+deger);
                break;
            }
            else if(deger<p.veri)
                p=p.sol;
            else if(deger>p.veri)
                p=p.sag;
        }
        System.out.println("Bulunamayan değer: "+deger);

    }

    public int Min()
    {
        Node p=root;
        if (p == null)
            return 0;
        while (p.sol != null){
        p = p.sol;
        }
        return p.veri;
        
    } 

    public int Max()
    {
        Node p=root;
        if (p == null)
            return 0;
        while (p.sag != null){
        p = p.sag;
        }
        return p.veri;
    } 

    public void Arama(int k)
    {
        boolean control = Arama2(root, k);
        if(control) 
            System.out.println("Bulundu "+k);
        else 
            System.out.println("Bulunamadı! "+k);
    }
    
    public boolean Arama2(Node root, int k)
    {
        Node yeni;
        if( root != null)
        {
            if(root.veri == k) 
                return true;
            else if(root.veri > k){
                yeni=root.sol;
                return Arama2(yeni,k);
            } 
            else if(root.veri < k) 
            {
                yeni=root.sag;
                Arama2(yeni,k);
            } 
        }
        return false;
    }

    public void Sil(int k)
    {
        bst.Node control = Sil2(root, k);
        if(control != null)
            System.out.println("Silindi");
        else System.out.println("Silinmedi");
    }

    public static Node Sil2(Node root, int key) {
        Node p=root;
        if(p==null)                    
            return p;                    
        if(key<p.veri)                 
            p.sol=Sil2(p.sol, key);  
        else if(key>p.veri)            
            p.sag=Sil2(p.sag,key); 
        else{
            if(p.sol!=null && p.sag!=null) {
                p.veri=(p.sag).veri;         
                p.sag=Sil2(p.sag,p.veri);  
            }
            else if(p.sol!=null)  
                p=p.sol;            
            else                      
                p=p.sag;            
            return p; 
        }
        return p;                        
                             
    }

    
    public Node findMax() {
        if(root==null) return null;   
            return findMax(root);         
    }
    
    
    private static Node findMax(Node root) {
        Node p=root;
        if(p.sag==null) return p; 
            return findMax(p.sag);   
    }
    
    
    public Node findMin() {
        Node p=root;                 
        if(p!=null)                 
            while(p.sol!=null)    
                p=p.sol;            
        return p;                    
    }


    public void printInorder(Node kok)
    {
        if( kok != null )
        {
            printInorder(kok.sol);
            System.out.print(kok.veri + " ");
            printInorder(kok.sag);
        }
    }

    public void printPreorder(Node kok)
    {
        if( kok != null )
        {
            System.out.print(kok.veri + " ");
            printPreorder(kok.sol);
            printPreorder(kok.sag);
        }
    }

    public void printPostorder(Node kok)
    {
        if( kok != null )
        {
            printPostorder(kok.sol);
            printPostorder(kok.sag);
            System.out.print(kok.veri + " ");
        }
    }
}
