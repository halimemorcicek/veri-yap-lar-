public class Tree {
    private int value;
    private Tree sol;
    private Tree sag;

    public Tree(int value, Tree sol, Tree sag) {
        this.value = value;
        this.sol = sol;
        this.sag = sag;
    }

	public Tree sol() {
		return null;
	}

	public Tree sag() {
		return null;
	}
}
