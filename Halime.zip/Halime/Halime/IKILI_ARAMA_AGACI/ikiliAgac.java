
public class ikiliAgac {
    Node root;
    
    
    private class Node
    {
        private Node parent;
        private Node sol; 
        private Node sag;
        private int veri;
        
        Node(int k)        
        {
            sol = sag = null;   
            veri = k;              
        }   
    }
    
   
    public void insert(int k)
    {
        Node n = new Node(k);
        insert(root,n);    
    }
    
    private void insert(Node kok, Node yeni)
    {
        if(root == null) 
            root = yeni;
        else{ 
            if(kok.veri > yeni.veri)
            {
                if(kok.sol == null) 
                {
                    kok.sol = yeni;
                    yeni.parent = kok.sol;
                }
                else insert(kok.sol,yeni); 
            }
            else
            { 
                if(kok.sag == null) 
                {
                    kok.sag = yeni;
                    yeni.parent = kok.sag;
                }
                else insert(kok.sag,yeni); 
            }
        }
    }
    
    public void search(int k)
    {
        boolean control = search(root, k);
        if(control) System.out.println("Bulundu");
        else System.out.println("Bulunamadı");
    }
    
    private boolean search(Node kok, int k)
    {
        if( kok != null)
        {
            if(kok.veri == k) return true;
            else if(kok.veri > k) search(kok.sol,k);
            else if(kok.veri < k) search(kok.sag,k);
        }
        return false;
    }
    
    public void max()
    {
        System.out.println(max(root));
    }
    // en büyük değer için ağacın en sağına gideriz
    private int max(Node kok)
    {
        if(kok!=null)
            max(kok.sag);
        return kok.veri;
    }
    
    public void min()
    {
        System.out.println(min(root));
    }
   
    private int min(Node kok)
    {
        if(kok!=null)
        {
            min(kok.sol);
        }
        return kok.veri;
    }
    
    public void printInorder(Node kok)
    {
        if( kok != null )
        {
            printInorder(kok.sol);
            System.out.print(kok.veri + " ");
            printInorder(kok.sag);
        }
    }

    public void printPreorder(Node kok)
    {
        if( kok != null )
        {
            System.out.print(kok.veri + " ");
            printPreorder(kok.sol);
            printPreorder(kok.sag);
        }
    }

    public void printPostorder(Node kok)
    {
        if( kok != null )
        {
            printPostorder(kok.sol);
            printPostorder(kok.sag);
            System.out.print(kok.veri + " ");
        }
    }
}