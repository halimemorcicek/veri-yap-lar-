public class Main {

    public static void main(String [] args)
    {
        Stack yigin = new Stack(10);
        yigin.push(9);      
        yigin.push(12);     
        yigin.push(18);     
        yigin.push(24);     
        yigin.push(43);     
        yigin.push(70);     
        yigin.push(14);     
        
       
        System.out.println("eleman : "+ yigin.pop());
        System.out.println("eleman : "+ yigin.pop());
        yigin.push(50);                              
        System.out.println("pop : "+ yigin.pop());  
        System.out.println("pop : "+ yigin.pop());  
        System.out.println("pop : "+ yigin.pop());  
        
        yigin.push(75);                            
        System.out.println("peek : "+ yigin.peek());
        

        while(yigin.isEmpty())
        {
            System.out.print(+yigin.pop()+"-->");
            System.out.print("");
        }
        System.out.print("");
}
    
}