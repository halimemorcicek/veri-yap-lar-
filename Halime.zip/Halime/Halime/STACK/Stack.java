public class Stack {
    private int[] eleman;
    private int top;
    private int maxDeger;    
    Stack(int boyut)     
    {
        eleman = new int[boyut];
        top = 0;        
        maxDeger = boyut;     
    }
    public void push(int element)
    {
        if(!isFull()){
            eleman[top] = element;    
            top++;                     
        }
    }
    
    public int pop()
    {
        top--;                      
        return eleman[top];      
    }
    
    public int peek()          
    {
        return eleman[top];
    }
    
    public boolean isEmpty()    
    {
        if(top > 0) return true;
        else return false;     
    }
    
    public boolean isFull() 
    {
        if(top == maxDeger) return true;
        else return false;         
    }
    
    public int boyut()   
    {
        return top;
    }
    
    public void list()  
    {
        for(int i = maxDeger - 1; i >= 0; i--) 
        {                                  
            if(eleman[i] != 0)                    
                System.out.print(eleman[i] + " ");
        }
    }
}