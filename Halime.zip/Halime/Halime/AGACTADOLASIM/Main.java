
   class Node {
    int key;
    Node sol, sag;
 
    public Node(int item)
    {
        key = item;
        sol = sag = null;
    }
}
 
class BinaryTree {
  
    Node root;
 
    BinaryTree() { root = null; }
   
   
    void printPreorder(Node node)
    {
        if (node == null)
            return;
 
        
        System.out.print(node.key + " ");
 
        
        printPreorder(node.sol);
 
        printPreorder(node.sag);
    }
    void printInorder(Node node)
    {
        if (node == null)
            return;
 
        
        printInorder(node.sol);
 
       
        System.out.print(node.key + " ");
 
       
        printInorder(node.sag);
    }
    void printPostorder(Node node)
    {
        if (node == null)
            return;
 
     
        printPostorder(node.sol);
 
       
        printPostorder(node.sag);
 
        System.out.print(node.key + " ");
    }
 
    void printPostorder() { printPostorder(root); }
    
    void printPreorder() { printPreorder(root); }
    void printInorder() { printInorder(root); }
   
 
    
    public static void main(String[] args)
    {
        BinaryTree tree = new BinaryTree();
        tree.root = new Node(1);
        tree.root.sol = new Node(2);
        tree.root.sag = new Node(3);
        tree.root.sol.sol = new Node(4);
        tree.root.sol.sag = new Node(5);
 
          
        System.out.println("Preorder sonuc");
        tree.printPreorder();
        System.out.println("Inorder sonuc ");
        tree.printInorder();

        System.out.println( "Postorder sonuc ");
        tree.printPostorder();
    }
}