import java.util.Scanner;

public class LinearSearch {
  public static int linearSearch(int[] dizi, int a) {
    for (int i = 0; i < dizi.length; i++) {
      if (dizi[i] == a) {
        return i;
      }
    }
    return -1;
  }
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Dizi boyutunu girin: ");
    int size = scanner.nextInt();
    int[] dizi = new int[size];
    for (int i = 0; i < size; i++) {
      System.out.print("eleman sayısı" + (i + 1) + ": ");
      dizi[i] = scanner.nextInt();
    }
    System.out.print("Aranacak elamanı giriniz: ");
    int a = scanner.nextInt();
    int result = linearSearch(dizi, a);
    if (result == -1) {
      System.out.println("eleman yok");
    } else {
      System.out.println("eleman index numarası " + result);
    }
  }
}
