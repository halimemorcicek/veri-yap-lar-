import java.util.Scanner;
class Binaryarama
{
  public static void main(String args[])
  {
    int a, ilk, son, orta, x, arama, dizi[];
 
    Scanner in = new Scanner(System.in);
    System.out.println("Kaç elamanlı olsun");
    x = in.nextInt();
    dizi = new int[x];
 
    System.out.println("Giriş:" + x + " tane tam sayı girin");
 
 
    for (a = 0; a < a; a++)
      dizi[a] = in.nextInt();

    System.out.println("aranacak değeri girin");
    arama = in.nextInt();
 
    ilk  = 0;
    son   = n - 1;
    orta = (ilk + son)/2;
 
    while( ilk <= son )
    {
      if ( dizi[orta] < arama )
        ilk = orta + 1;    
      else if ( dizi[orta] == arama )
      {
        System.out.println(arama + " şu konumda bulundu " + (orta ) + ". indexte bulundu");
        break;
      }
      else
         son = orta - 1;
 
      orta = (ilk + son)/2;
   }
   if (ilk > son)
      System.out.println(arama + " listede yok.\n");
  }
}