class kuyruk{
    private int boyut;
    private int[] kuyrukDizi;
    private int bas;
    private int son;
    private int elemanSayisi;
    public kuyruk(int s){
        boyut=s;
        kuyrukDizi=new int[boyut];
        bas=0;
        son=-1;
        elemanSayisi=0;
    }
    
    public void ekle(int e){
        if(son==boyut-1)
            son=-1;
        kuyrukDizi[++son]=e;
        elemanSayisi++;
    }

    
    public int cikart(){
        int tmp=kuyrukDizi[bas++];
        if(bas==boyut)
            bas=0;
        elemanSayisi--;
        return tmp;
    }

    public boolean bosmu(){
        return(elemanSayisi==0);
    }

}