public class DBList {
    Nod govde;
    
    public void ekle(String il)
    {
        Nod yeniNode=new Nod();
        yeniNode.setIsim(il);
        if(govde==null)
        {
            govde=yeniNode;
            govde.setSonraki(yeniNode);
            govde.setOnceki(yeniNode);
            
            return;
        }
        Nod temp=govde.getOnceki();
        temp.setSonraki(yeniNode);
        yeniNode.setOnceki(temp);
        yeniNode.setSonraki(govde);
        govde.setOnceki(yeniNode);
    }


    public void sil(String ad)
    {
        if(govde==null)
        {
            System.out.println("Liste boş"); return;
        }
        Nod temp=govde;
        while(temp.getIsim()!=ad)
        {
            temp=temp.sonraki; 
        }
        temp.onceki.setSonraki(temp.sonraki);
        temp.sonraki.setOnceki(temp.onceki);
    
    }
    public void listele()
    {
        if(govde==null)
        {
        System.out.println("liste boş");
        return;
        }

        System.out.println("Listesi: ");
        System.out.print(govde.il+" <--> ");
        Nod temp=govde.sonraki;
        while(temp!=govde)
        {
            System.out.print(temp.il+" <--> ");
            temp=temp.sonraki;
            if(temp.sonraki==null)
                System.out.print("dddddd");
        }
    }
    
}