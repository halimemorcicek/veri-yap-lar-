public class Nod {

    String ilk;
    Nod sonraki=null;
    Nod onceki=null;
    
    public String getIsim() {
        return ilk;
    }
    public void setIsim(String ilk) {
        this.ilk = ilk;
    }
    public Nod getSonraki() {
        return sonraki;
    }
    public void setSonraki(Nod sonraki) {
        this.sonraki = sonraki;
    }
    public Nod getOnceki() {
        return onceki;
    }
    public void setOnceki(Nod onceki) {
        this.onceki = onceki;
    }
}