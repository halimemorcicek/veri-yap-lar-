public class Main {
    public static void main(String[] args) {
    
        DBList d=new DBList();
        d.ekle("Maraş");   
        d.ekle("Ankara");
        d.ekle("urfa");
        d.ekle("Adana");
        d.ekle("Van");
        d.listele();
        d.sil("Hatay");
        System.out.println();
        d.listele();
    }
}