class QuickSort 
{ 
    int partition(int dizi[], int düsük, int yuksek) 
    { 
        int pivot = dizi[yuksek];  
        int i = (düsük-1); 
        for (int j=düsük; j<yuksek; j++) 
        { 
            
            if (dizi[j] <= pivot) 
            { 
                i++; 
                
                int temp = dizi[i]; 
                dizi[i] = dizi[j]; 
                dizi[j] = temp; 
            } 
         
        int temp = dizi[i+1]; 
        dizi[i+1] = dizi[yuksek]; 
        dizi[yuksek] = temp; 
        } 
        return i+1;
    }

    void sort(int dizi[], int düsük, int yuksek) 
    { 
        if (düsük < yuksek) 
        { 
            
            int pi = partition(dizi, düsük, yuksek); 
  
            sort(dizi, düsük, pi-1); 
            sort(dizi, pi+1, yuksek); 

        }
    } 

  
    static void printdiziay(int dizi[]) 
    { 
        int n = dizi.length; 
        for (int i=0; i<n; ++i) 
            System.out.print(dizi[i]+" "); 
        System.out.println(); 
    } 


    public static void main(String args[]) 
    { 
        int dizi[] = {20, 77, 18, 9, 12, 5}; 
        int n = dizi.length; 
  
        QuickSort ob = new QuickSort(); 
        ob.sort(dizi, 0, n-1); 
  
        System.out.println("Sıralı dizi: "); 
        printdiziay(dizi); 
    } 
} 
