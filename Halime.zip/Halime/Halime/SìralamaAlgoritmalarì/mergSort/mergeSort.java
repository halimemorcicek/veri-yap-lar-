public class mergeSort {
private int[] list;

public mergeSort(int[] listToSort) {list = listToSort; }

public int[] getList() { return list; }


public void sort() { list = sort(list); }


private int[] sort(int[] dizi) {
    if (dizi.length == 1) 
        return dizi;
    else 
    {
        
        int[] sol = new int[dizi.length/2];
        System.arraycopy(dizi, 0, sol, 0, sol.length);
        
        for(int i = 0;i< dizi.length ; i++)
            System.out.print(dizi[i] + " ");
        System.out.println("");

        
        int[] sag = new int[dizi.length-sol.length];
        System.arraycopy(dizi, sol.length, sag, 0, sag.length);

        for(int i = 0;i< dizi.length ; i++)
            System.out.print(dizi[i] + " ");
        System.out.println("");
        
        
        sol = sort(sol);
        sag = sort(sag);
        
        for(int i = 0;i< dizi.length ; i++)
            System.out.print(dizi[i] + " ");
        System.out.println("");
        
        
        merge(sol, sag, dizi);

        

        return dizi;
    }
}


private void merge(int[] sol, int[] sag, int[] sonuc) {
    int x = 0; int y = 0; int k = 0;
    
    while (x < sol.length && y < sag.length)
    { 
        if (sol[x] < sag[y]) 
        { 
            sonuc[k] = sol[x]; x++; 
        }
        else 
        { 
            sonuc[k] = sag[y]; y++; 
        }
        k++;
    }
    int[] rest; int restIndex;
    if (x >= sol.length) 
    { 
        rest = sag; 
        restIndex = y; 
    }
    else 
    { 
        rest = sol; 
        restIndex = x; 
    }
    for (int i=restIndex; i<rest.length; i++) 
    { 
        sonuc[k] = rest[i]; 
        k++; 
    }
}

public static void main(String[] args) {
    int[] dizi = {10,35,36,98,74,56,51,2,7,9};
    System.out.println("Sırasıs:");
    for(int i = 0;i< dizi.length ; i++)
    {
        System.out.print(dizi[i] + " ");
    }
    mergeSort sortObj = new mergeSort(dizi);
    sortObj.sort();
    System.out.println("");
    System.out.println("Sıralı:");
    int [] sirali = sortObj.getList();
    for(int i = 0;i< sirali.length ; i++)
    {
        System.out.print(sirali[i] + " ");
    }
}
}
