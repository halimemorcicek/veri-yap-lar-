class insertion{
    void insertion(int dizi[])
    {
        int i,k,y;
        int n=dizi.length;
        for(k=1; k<n; k++)
        {
            y=dizi[k];
            for(i=k-1; i>=0 && y<dizi[i]; i--)
                dizi[i+1]=dizi[i];
            dizi[i+1]=y;
        }
    }

    void diziYaz(int dizi[]) 
    { 
        int n = dizi.length; 
        for (int i=0; i<n; ++i) 
            System.out.print(dizi[i] + " "); 
        System.out.println(); 
    } 
  
    
    public static void main(String args[]) 
    { 
        insertion ob = new insertion(); 
        int dizi[] = {10,40,15,5,9,85,2}; 
        ob.insertion(dizi); 
        System.out.println("Sıralı Dizi: "); 
        ob.diziYaz(dizi); 
    } 
}
